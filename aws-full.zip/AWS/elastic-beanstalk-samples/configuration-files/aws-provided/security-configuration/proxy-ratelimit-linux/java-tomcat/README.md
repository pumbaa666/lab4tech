```
For Java Tomcat environments running the default Apache proxy server browse to:

rate-limit-connections-java-tomcat

For Java Tomcat environments configured to use the Nginx proxy browse to:

rate-limit-connections-nginx-java-tomcat
```
