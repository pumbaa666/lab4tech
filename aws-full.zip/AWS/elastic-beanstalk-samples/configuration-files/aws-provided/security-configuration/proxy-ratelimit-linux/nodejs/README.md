```
For Node.js environments running the Nginx proxy server use:

rate-limit-connections-nodejs.config

For Node.js environments running the default Apache proxy server use:

rate-limit-connections-apache-nodejs.config

```
