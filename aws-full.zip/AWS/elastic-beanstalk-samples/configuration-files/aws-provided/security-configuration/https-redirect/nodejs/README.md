```
For Node.js environments running the default Nginx proxy use:

https-redirect-nodejs.config

For Node.js environments configured to run the Apache proxy server use:

https-redirect-apache-nodejs.config
```
