###################################################################################################
#### This is a collection of configuration files, one per platform. Each configuration file
#### configures the platform's proxy server that runs in front of your application to enable WebSockets.
####
#### These configuration files work with single-instance and load-balanced environments.
####
#### Browse to the folder matching your environment's platform for platform-specific information.
###################################################################################################
