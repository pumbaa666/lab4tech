[My estimate for private server](https://calculator.aws/#/estimate?id=f1bdb6f4195ac3b3ebe7fe6871e500345c699c6b)

[AWS Free Tier](https://aws.amazon.com/free/?all-free-tier.sort-by=item.additionalFields.SortRank&all-free-tier.sort-order=asc&awsf.Free+Tier+Types=*all&awsf.Free+Tier+Categories=*all)
[EC2](https://aws.amazon.com/ec2/?did=ft_card&trk=ft_card) (750h / month)
[EC2 Pricing](https://aws.amazon.com/ec2/pricing/?p=pm&c=ec2&z=4)
[S3 Storage](https://aws.amazon.com/s3/?did=ft_card&trk=ft_card) (Bucket)